from time import sleep

from userbot import CMD_HANDLER as cmd
from userbot import CMD_HELP
from userbot.utils import edit_or_reply, man_cmd


@man_cmd(pattern="vm(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, "**Wait Yaaa Bosssss**")
    sleep(2)
    await xx.edit(
     "**Berikut Harga VPS / RDP :**\n"
     "**ISP by MICROSOFT **\n"
     "┏━━━━━━━━━━━━━━━━\n"
     "┣ **Paket A  1 GB RAM** - `30.000`\n"
     "┣ **Paket B  2 GB RAM** - `60.000`\n"
     "┣ **Paket C  4 GB RAM** - `90.000`\n"
     "┣ **Paket D  8 GB RAM** - `140.000`\n"
     "┣ **Paket E 16 GB RAM** - `200.000`\n"
     "┗━━━━━━━━━━━━━━━━\n"
     "**PENTING!! :**\n"
     "`☑️ Khusus VPS free Script Jualan VPN` \n"
     "`☑️ Bebas Restart`\n"
     "`☑️ Bebas Req OS dan Negara`\n"
    )

@man_cmd(pattern="p(?: |$)(.*)")
async def _(event):
    await event.client.send_message(
        event.chat_id,
        "**Assalamualaikum Dulu Biar Sopan**",
        reply_to=event.reply_to_msg_id,
    )
    await event.delete()

@man_cmd(pattern="azr(?: |$)(.*)")
async def _(event):
    await event.client.send_message(
        event.chat_id,
        "**Azure Ready nih Bossss**\n┏━━━━━━━━━━━━━━━━━━━\n  ┣\n  ┣`Azure Pay as`\n ┣`Azure FT \n┣` Azure Student`\n ┣\n┗━━━━━━━━━━━━━━━━━━━\n **Testimoni** **[KLIK](t.me/free_pulsa)**\n ",
        reply_to=event.reply_to_msg_id,
    )
    await event.delete()

@man_cmd(pattern="bayar(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, "**Wait Yaaa Bosssss**")
    sleep(2)
    await xx.edit("**Pembayaran Yang Kami Dukung...**\n**Payments We Support...**\n\n┏━━━━━━━━━━━━━━━━━━━\n┣ **Dana** - `089653457526`\n┣ **Gopay** - `089653457526`\n┣ **Ovo** - `089653457526`\n┣ **Bank Bri** - `389401005443508`\n┣ **Bank Bca** - `1260766011`\n┣ **Qriz Dana** - [KLIK](www.warungbullove.com/barcode.jpg)\n┣ **PayPal** - [KLIK](https://www.paypal.me/warungbullove)\n┣**Semua Atas Nama** - `IQBAL FAJAR I`\n┗━━━━━━━━━━━━━━━━━━━")

@man_cmd(pattern="isi(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, "**Wait Yaaa Bosssss**")
    sleep(2)
    await xx.edit("**FORMAT TRANSAKSI**\n\n┏━━━━━━━━━━━━━━━━\n┣ `Jual Beli Apa  :` \n┣ `Penjual Siapa  : `\n┣ `Pembeli Siapa  :`\n┣ `Harga Berapa   :`\n┗━━━━━━━━━━━━━━━━ \n**PENTING!!!**\n`☑️ Harap pasikan Transaksi tidak ada miskom buyer dan seller.` \n`☑️ Jika Transaksi Cancel Fee tetap Terpotong, jika tdk mau Terpotong Silahkan cari penjual lain.`\n`☑️ Jadikan Saya Sebagai admin grub ini`\n`✅ Janggn ganti judul MC.`")

@man_cmd(pattern="isi2(?: |$)(.*)")
async def _(event):
    xi = event.pattern_match.group(1)
    xx = await edit_or_reply(event, "**Wait Yaaa Bosssss**")
    sleep(2)
    await xx.edit(
        "**Jika sudah sepakat #DONE**\n"
        "**Penjual Silahkan Di isi :**\n\n"
        "┏━━━━━━━━━━━━━━━━━━━\n"
	"┣ **Nama Bank** - \n"
	"┣ **Atas Nama** - \n"
	"┣ **No Rek** - \n"
       f"┣ **Fee Rekber** : **{xi}** \n"
	"┗━━━━━━━━━━━━━━━━━━━"
)


@man_cmd(pattern="fee(?: |$)(.*)")
async def _(event):
    xi = event.pattern_match.group(1).lower()
    xx = await edit_or_reply(event, "**Wait Yaaa Bosssss**")
    sleep(2)
    await xx.edit(
    f"**BIAYA REKBER SEBESAR :**\n"
"╔══════════════╗\n"
f"         ⛑**{xi}**   `ribu rupiah⛑`\n"
"╚══════════════╝\n"
     "**Pembayaran Yang Kami Dukung**\n"
     "┏━━━━━━━━━━━━━━━━\n"
     "┣ **Dana** - `089653457526`\n"
     "┣ **Gopay** - `089653457526`\n"
     "┣ **Ovo** - `089653457526`\n"
     "┣ **Bank Bri** - `389401005443508`\n"
     "┣ **Bank Bca** - `1260766011`\n"
     "┣ **Qriz Dana** - [KLIK](www.warungbullove.com/barcode.jpg)\n"
     "┣ **PayPal** - `off`\n"
     "┣ **Semua Atas Nama** - `IQBAL FAJAR I`\n"
     "┗━━━━━━━━━━━━━━━━\n"
     "**PENTING!! :**\n"
     "`☑️ Khusus transaksi 500K ke-atas,Silahkan TF saja ke Bank BCA/BRI` \n"
     "`☑️ Wajib sertakan bukti TF ke Grub ini.\n"
     "`☑️ Untuk pencairan selain BANK BCA & BRI, kena biaya tf 6500`\n"
     "`✅`""**Jika Admin slowrepon silahkan wa**""` 089653457526` "
    )


@man_cmd(pattern="done(?: |$)(.*)")
async def _(event):
    xi = event.pattern_match.group(1).lower()
    xx = await edit_or_reply(event, "`tunggu 1 menit  Yaaa Bosssss..`")
    sleep(4)
    await xx.edit(
    f"**Transfer Berhasil sebesar   :**\n"
"╔══════════════╗\n"
f"       ⛑**{xi}**   `ribu rupiah⛑`\n"
"╚══════════════╝\n"
"`Silahkan di cek....` \n"
"`Trimakasih Boskuuu...` \n"
)

@man_cmd(pattern="biaya(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, "**Wait Yaaa Bosssss**")
    sleep(2)
    await xx.edit(
    "**BIAYA REKBER WARUNG BULLOVE**\n\n"
    "┏━━━━━━━━━━━━━━━━\n"
    "┣ **>10.000-50.000**    :`5k`\n"
    "┣ **>50.001-100.000**   :`8k`\n"
    "┣ **>100.001-150.000**   :`10k`\n"
    "┣ **>150.001-250.000**  :`15k`\n"
    "┣ **>250.001-350.000**  :`20k`\n"
    "┣ **>350.001-500.000**  :`25k`\n"
    "┣ **>500.001-800.000**  :`40k`\n"
    "┣ **>850.001-1.000.000**:`60k`\n"
    "┗━━━━━━━━━━━━━━━━\n\n"
    "**Penggunaan Jasa Rekber :**\n"
    "`☑️ Jam Rekber 24 Jam Kecuali Tidur.` \n"
    "`☑️ Buat grub telegram Dengan nama`**REKBER #tanggal** \n"
    "`☑️ Isi anggota grub Max 3 orang termasuk saya`\n"
    "`✅ `**Jika Admin slowrepon silahkan wa** `089653457526`"
    )

@man_cmd(pattern="pe(?: |$)(.*)")
async def _(event):
    await event.client.send_message(
        event.chat_id,
        "**Assalamualaikum Warahmatullahi Wabarakatuh**",
        reply_to=event.reply_to_msg_id,
    )
    await event.delete()


@man_cmd(pattern="P(?: |$)(.*)")
async def _(event):
    me = await event.client.get_me()
    xx = await edit_or_reply(event, f"**Haii Salken Saya {me.first_name}**")
    sleep(2)
    await xx.edit("**Assalamualaikum...**")


@man_cmd(pattern="l(?: |$)(.*)")
async def _(event):
    await event.client.send_message(
        event.chat_id, "**Wa'alaikumsalam**", reply_to=event.reply_to_msg_id
    )
    await event.delete()


@man_cmd(pattern="a(?: |$)(.*)")
async def _(event):
    me = await event.client.get_me()
    xx = await edit_or_reply(event, f"**Haii Salken Saya {me.first_name}**")
    sleep(2)
    await xx.edit("**Assalamualaikum**")


@man_cmd(pattern="j(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, "**JAKA SEMBUNG BAWA GOLOK**")
    sleep(3)
    await xx.edit("**NIMBRUNG GOBLOKK!!!🔥**")


@man_cmd(pattern="k(?: |$)(.*)")
async def _(event):
    me = await event.client.get_me()
    xx = await edit_or_reply(event, f"**Hallo KIMAAKK SAYA {me.first_name}**")
    sleep(2)
    await xx.edit("**LU SEMUA NGENTOT 🔥**")


@man_cmd(pattern="ass(?: |$)(.*)")
async def _(event):
    xx = await edit_or_reply(event, "**Salam Dulu Biar Sopan**")
    sleep(2)
    await xx.edit("**السَّلاَمُ عَلَيْكُمْ وَرَحْمَةُ اللهِ وَبَرَكَاتُهُ**")


CMD_HELP.update(
    {
        "salam": f"**Plugin : **`salam`\
        \n\n  •  **Syntax :** `{cmd}p`\
        \n  •  **Function : **Assalamualaikum Dulu Biar Sopan..\
        \n\n  •  **Syntax :** `{cmd}pe`\
        \n  •  **Function : **salam Kenal dan salam\
        \n\n  •  **Syntax :** `{cmd}l`\
        \n  •  **Function : **Untuk Menjawab salam\
        \n\n  •  **Syntax :** `{cmd}ass`\
        \n  •  **Function : **Salam Bahas arab\
        \n\n  •  **Syntax :** `{cmd}semangat`\
        \n  •  **Function : **Memberikan Semangat.\
        \n\n  •  **Syntax :** `{cmd}ywc`\
        \n  •  **Function : **nMenampilkan Sama sama\
        \n\n  •  **Syntax :** `{cmd}sayang`\
        \n  •  **Function : **Kata I Love You.\
        \n\n  •  **Syntax :** `{cmd}k`\
        \n  •  **Function : **LU SEMUA NGENTOT 🔥\
        \n\n  •  **Syntax :** `{cmd}j`\
        \n  •  **Function : **NIMBRUNG GOBLOKK!!!🔥\
    "
    }
)
